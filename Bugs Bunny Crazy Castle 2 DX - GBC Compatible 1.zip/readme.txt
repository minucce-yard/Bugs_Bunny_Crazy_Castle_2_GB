Bugs Bunny Crazy Castle 2 DX - GBC Compatible


Latest:
2021-10-21



//////////////////////////////////////////////////////////////////



Bugs Bunny Crazy Castle 2 DX  (FroggestSpirit):

-  Original Bugs Bunny Crazy Castle 2, The (USA) rom


-  Apply patch 1.0
   https://www.romhacking.net/hacks/944/


   Then dx_basic.ips



______________________________________________________________



Basic:


gbc_compatible

*  Fixes vram graphics corruption
   Fixes missing ending scene



_______________________________________________



Commits:


1 - gbc_compatible released


_______________________________________________



Visit:

*  Source Code
   https://github.com/minucce-yard/Bugs_Bunny_Crazy_Castle_2_GB



_______________________________________________



Comments:

*  Cheats

   c380 = level  (00-1c)
   c3b8 = keys   (00-08)
   c3cd = arrow  (00-08)
